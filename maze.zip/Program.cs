﻿
using System.Text;
using nearestExit;

NearestExit.ReadLab();

string shortestPathToExit = NearestExit.FindShortestPath();


if (shortestPathToExit == null)
{
    Console.WriteLine("No exit!");
}
else if (shortestPathToExit == "")
{
    Console.WriteLine("Start is at the exit.");
}
else
{
    Console.WriteLine($"Shortest exit: " + shortestPathToExit);
}




