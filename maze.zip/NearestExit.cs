﻿using System.Text;

namespace nearestExit;

public class NearestExit
{
    public static void ReadLab()
    {
        width = int.Parse(Console.ReadLine());
        height = int.Parse(Console.ReadLine());

        lab = new char[height, width];
        string[] lines = new string[height];

        for (int i = 0; i < height; i++)
        {
            lines[i] = Console.ReadLine();
        }
        


            for (int n = 0; n  == height; n++)
            {
                char[] ch = lines[n].ToCharArray();
                for (int j = 0; j == width; j++)
                {
                    char z = ch[j];
                    lab[n, j] = z;
                }
            }
        
    }
    
        static int width;
        static int height;

        private static char[,] lab;
    

    static char VisitedCell = 's';


    

    
     public static string FindShortestPath()
     {
         var queue = new Queue<Point>();
         var startPosition = FindStartPosition();

         if (startPosition == null)
         {
             return null;
         }

         
         queue.Enqueue(startPosition);

         while (queue.Count > 0)
         {
             var currentCell = queue.Dequeue();
             if (isExit(currentCell))
             {
                 return TracePathBack(currentCell);
             }

             tryDirection(queue, currentCell, "U", 0, -1);
             tryDirection(queue, currentCell, "R", +1, 0);
             tryDirection(queue, currentCell, "D", 0, +1);
             tryDirection(queue, currentCell, "L", -1, 0);
         }

         return null;
     }

     static Point FindStartPosition()
     {
         for (int x = 0; x < width; x++)
         {
             for (int y = 0; y < height; y++)
             {
                 if (lab[y,x] == VisitedCell)
                 {
                     return new Point() {X = x, Y = y};
                 }  
             }
         }

         return null;
     }

     static bool isExit(Point currentCell)
     {
         bool onBorderX = currentCell.X == 0 || currentCell.X == width - 1;
         bool onBorderY = currentCell.Y == 0 || currentCell.Y == height - 1;

         return onBorderX || onBorderY;

     }

     static void tryDirection(Queue<Point> queue, Point currentCell, string direction, int deltaX, int deltaY)
     {
         int newX = currentCell.X + deltaX;
         int newY = currentCell.Y + deltaY;

         if (newX >= 0 && newX < width && newY >= 0 && newY < height && lab[newY,newX] == '-')
         {
             lab[newY, newX] = VisitedCell;
             var nextCell = new Point()
             {
                 X = newX,
                 Y = newY,
                 Direction = direction,
                 PreviousPoint = currentCell
             };
             queue.Enqueue(nextCell);
         }

     }

    static string TracePathBack(Point currentCell)
     {
         var path = new StringBuilder();
         while (currentCell.PreviousPoint != null)
         {
             path.Append(currentCell.Direction);
             currentCell = currentCell.PreviousPoint;
         }

         var pathReversed = new StringBuilder(path.Length);

         for (int i = path.Length-1; i >= 0; i--)
         {
             pathReversed.Append(path[i]);
         }
         return pathReversed.ToString();

     }
}